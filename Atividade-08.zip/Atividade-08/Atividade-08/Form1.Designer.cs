﻿namespace Atividade_08
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtividade1 = new System.Windows.Forms.Button();
            this.btnAtividade2 = new System.Windows.Forms.Button();
            this.btnAtividade3 = new System.Windows.Forms.Button();
            this.btnAtividade4 = new System.Windows.Forms.Button();
            this.btnAtividade5 = new System.Windows.Forms.Button();
            this.btnAtividade6 = new System.Windows.Forms.Button();
            this.btnAtividade7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtividade1
            // 
            this.btnAtividade1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade1.Location = new System.Drawing.Point(0, 1);
            this.btnAtividade1.Name = "btnAtividade1";
            this.btnAtividade1.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade1.TabIndex = 1;
            this.btnAtividade1.Text = "Exercício 1";
            this.btnAtividade1.UseVisualStyleBackColor = true;
            this.btnAtividade1.Click += new System.EventHandler(this.btnAtividade1_Click);
            // 
            // btnAtividade2
            // 
            this.btnAtividade2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade2.Location = new System.Drawing.Point(109, 1);
            this.btnAtividade2.Name = "btnAtividade2";
            this.btnAtividade2.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade2.TabIndex = 2;
            this.btnAtividade2.Text = "Exercício 2";
            this.btnAtividade2.UseVisualStyleBackColor = true;
            this.btnAtividade2.Click += new System.EventHandler(this.btnAtividade2_Click);
            // 
            // btnAtividade3
            // 
            this.btnAtividade3.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade3.Location = new System.Drawing.Point(218, 1);
            this.btnAtividade3.Name = "btnAtividade3";
            this.btnAtividade3.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade3.TabIndex = 3;
            this.btnAtividade3.Text = "Exercício 3";
            this.btnAtividade3.UseVisualStyleBackColor = true;
            this.btnAtividade3.Click += new System.EventHandler(this.btnAtividade3_Click);
            // 
            // btnAtividade4
            // 
            this.btnAtividade4.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade4.Location = new System.Drawing.Point(327, 1);
            this.btnAtividade4.Name = "btnAtividade4";
            this.btnAtividade4.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade4.TabIndex = 4;
            this.btnAtividade4.Text = "Exercício 4";
            this.btnAtividade4.UseVisualStyleBackColor = true;
            this.btnAtividade4.Click += new System.EventHandler(this.btnAtividade4_Click);
            // 
            // btnAtividade5
            // 
            this.btnAtividade5.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade5.Location = new System.Drawing.Point(0, 53);
            this.btnAtividade5.Name = "btnAtividade5";
            this.btnAtividade5.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade5.TabIndex = 5;
            this.btnAtividade5.Text = "Exercício 5";
            this.btnAtividade5.UseVisualStyleBackColor = true;
            this.btnAtividade5.Click += new System.EventHandler(this.btnAtividade5_Click);
            // 
            // btnAtividade6
            // 
            this.btnAtividade6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade6.Location = new System.Drawing.Point(109, 53);
            this.btnAtividade6.Name = "btnAtividade6";
            this.btnAtividade6.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade6.TabIndex = 6;
            this.btnAtividade6.Text = "Exercício 6";
            this.btnAtividade6.UseVisualStyleBackColor = true;
            this.btnAtividade6.Click += new System.EventHandler(this.btnAtividade6_Click);
            // 
            // btnAtividade7
            // 
            this.btnAtividade7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtividade7.Location = new System.Drawing.Point(218, 53);
            this.btnAtividade7.Name = "btnAtividade7";
            this.btnAtividade7.Size = new System.Drawing.Size(103, 46);
            this.btnAtividade7.TabIndex = 7;
            this.btnAtividade7.Text = "Exercício 7";
            this.btnAtividade7.UseVisualStyleBackColor = true;
            this.btnAtividade7.Click += new System.EventHandler(this.btnAtividade7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 441);
            this.Controls.Add(this.btnAtividade7);
            this.Controls.Add(this.btnAtividade6);
            this.Controls.Add(this.btnAtividade5);
            this.Controls.Add(this.btnAtividade4);
            this.Controls.Add(this.btnAtividade3);
            this.Controls.Add(this.btnAtividade2);
            this.Controls.Add(this.btnAtividade1);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.Text = "Menu Principal";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnAtividade1;
        private System.Windows.Forms.Button btnAtividade2;
        private System.Windows.Forms.Button btnAtividade3;
        private System.Windows.Forms.Button btnAtividade4;
        private System.Windows.Forms.Button btnAtividade5;
        private System.Windows.Forms.Button btnAtividade6;
        private System.Windows.Forms.Button btnAtividade7;
    }
}

