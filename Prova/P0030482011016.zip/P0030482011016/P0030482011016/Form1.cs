﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482011016
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int meses = 16, semanas = 4, i, j;
            double totalMensal = 0.0, totalGeral = 0.0;
            string[,] matriz = new string[meses, semanas];                       

            for(i=0; i<meses; i++)
            {
                for(j=0; j<semanas; j++)
                {
                    if (Double.TryParse((Interaction.InputBox($"Informe o valor do mes {i+1} e da semana {j+1}:", "Valor:")), out double valor))
                    {
                        totalMensal += valor;
                        matriz[i, j] = valor.ToString("N2");
                        lstSaida.Items.Add($"Total do mês: {i + 1} Semana: {j + 1} R$" + matriz[i, j] + "\n");

                    }
                    else
                    {
                        MessageBox.Show("Informe um valor numérico!");
                        lstSaida.Items.Clear();
                        return;
                    }
                }
                lstSaida.Items.Add($">>Total Mês R$" + totalMensal.ToString("N2") + "\n");
                lstSaida.Items.Add("-----------------------------------" + "\n");
                totalGeral += totalMensal;
                totalMensal = 0.0;
            }    

            lstSaida.Items.Add(">>Total Geral: R$" + totalGeral.ToString("N2"));
        }
    }
}
